import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Users, 
  Target, 
  Settings, 
  Bell, 
  Search, 
  Plus, 
  Mail, 
  Phone, 
  MapPin, 
  CheckCircle2, 
  Clock, 
  MessageSquare,
  ChevronRight,
  MoreVertical,
  ArrowUpRight,
  ArrowDownRight,
  TrendingUp,
  History,
  FileText,
  Lock,
  User,
  LogOut,
  AlertCircle,
  Send
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from './lib/utils';
import { Contact, DashboardStats } from './types';

// --- Auth Components ---

const Login = ({ onLogin, onSwitchToRegister }: { onLogin: (token: string, user: any) => void, onSwitchToRegister: () => void }) => {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier, password }),
      });
      const data = await res.json();
      if (res.ok) {
        onLogin(data.token, data.user);
      } else {
        setError(data.error || 'Erro ao fazer login');
      }
    } catch (err) {
      setError('Erro de conexão com o servidor');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white p-8 rounded-3xl shadow-xl border border-slate-100 w-full max-w-md"
      >
        <div className="flex flex-col items-center mb-8">
          <div className="bg-indigo-600 p-3 rounded-2xl mb-4 shadow-lg shadow-indigo-200">
            <TrendingUp className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-slate-900">CRM Vendas Pro</h1>
          <p className="text-slate-500 text-sm mt-1">Bem-vindo de volta! Faça login para continuar.</p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-center space-x-3 text-rose-600 text-sm">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2 ml-1">E-mail ou Usuário</label>
            <div className="relative">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input 
                type="text" 
                required
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                placeholder="ex: joao@email.com"
                className="w-full pl-12 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2 ml-1">Senha</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input 
                type="password" 
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-12 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
              />
            </div>
          </div>
          <button 
            type="submit" 
            disabled={loading}
            className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-bold shadow-lg shadow-indigo-200 transition-all active:scale-[0.98] disabled:opacity-50"
          >
            {loading ? 'Entrando...' : 'Entrar na Plataforma'}
          </button>
        </form>

        <div className="mt-8 text-center">
          <p className="text-slate-500 text-sm">
            Não tem uma conta?{' '}
            <button onClick={onSwitchToRegister} className="text-indigo-600 font-bold hover:underline">
              Cadastre-se agora
            </button>
          </p>
        </div>
      </motion.div>
    </div>
  );
};

const Register = ({ onRegisterSuccess, onSwitchToLogin }: { onRegisterSuccess: () => void, onSwitchToLogin: () => void }) => {
  const [formData, setFormData] = useState({
    email: '',
    username: '',
    phone: '',
    password: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      if (res.ok) {
        onRegisterSuccess();
      } else {
        setError(data.error || 'Erro ao cadastrar');
      }
    } catch (err) {
      setError('Erro de conexão com o servidor');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white p-8 rounded-3xl shadow-xl border border-slate-100 w-full max-w-md"
      >
        <div className="flex flex-col items-center mb-8">
          <div className="bg-indigo-600 p-3 rounded-2xl mb-4 shadow-lg shadow-indigo-200">
            <TrendingUp className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-slate-900">Criar Conta</h1>
          <p className="text-slate-500 text-sm mt-1">Junte-se ao CRM Vendas Pro hoje.</p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-center space-x-3 text-rose-600 text-sm">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5 ml-1">E-mail</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input 
                type="email" 
                required
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                placeholder="ex: joao@email.com"
                className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Usuário</label>
            <div className="relative">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input 
                type="text" 
                required
                value={formData.username}
                onChange={(e) => setFormData({...formData, username: e.target.value})}
                placeholder="ex: joaosilva"
                className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Telefone</label>
            <div className="relative">
              <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input 
                type="tel" 
                required
                value={formData.phone}
                onChange={(e) => setFormData({...formData, phone: e.target.value})}
                placeholder="(11) 99999-9999"
                className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Senha</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input 
                type="password" 
                required
                value={formData.password}
                onChange={(e) => setFormData({...formData, password: e.target.value})}
                placeholder="••••••••"
                className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
              />
            </div>
          </div>
          <button 
            type="submit" 
            disabled={loading}
            className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-bold shadow-lg shadow-indigo-200 transition-all active:scale-[0.98] disabled:opacity-50"
          >
            {loading ? 'Cadastrando...' : 'Criar minha Conta'}
          </button>
        </form>

        <div className="mt-8 text-center">
          <p className="text-slate-500 text-sm">
            Já tem uma conta?{' '}
            <button onClick={onSwitchToLogin} className="text-indigo-600 font-bold hover:underline">
              Faça login
            </button>
          </p>
        </div>
      </motion.div>
    </div>
  );
};

// --- Components ---

const Modal = ({ isOpen, onClose, title, children }: { isOpen: boolean, onClose: () => void, title: string, children: React.ReactNode }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden"
      >
        <div className="p-6 border-b border-slate-100 flex justify-between items-center">
          <h2 className="text-xl font-bold text-slate-800">{title}</h2>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
            <Plus className="w-6 h-6 rotate-45 text-slate-400" />
          </button>
        </div>
        <div className="p-6 max-h-[80vh] overflow-y-auto custom-scrollbar">
          {children}
        </div>
      </motion.div>
    </div>
  );
};

const NewContactForm = ({ onSave, onCancel, token }: { onSave: (c: any) => void, onCancel: () => void, token: string }) => {
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    phone: '',
    email: '',
    role: '',
    location: '',
    status: 'Lead'
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/contacts', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(formData),
      });
      if (res.ok) {
        const newContact = await res.json();
        onSave(newContact);
      }
    } catch (err) {
      console.error("Erro ao salvar contato:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="sm:col-span-2">
          <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Nome Completo</label>
          <input 
            type="text" 
            required
            value={formData.name}
            onChange={(e) => setFormData({...formData, name: e.target.value})}
            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
          />
        </div>
        <div>
          <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Empresa</label>
          <input 
            type="text" 
            value={formData.company}
            onChange={(e) => setFormData({...formData, company: e.target.value})}
            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
          />
        </div>
        <div>
          <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Cargo</label>
          <input 
            type="text" 
            value={formData.role}
            onChange={(e) => setFormData({...formData, role: e.target.value})}
            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
          />
        </div>
        <div>
          <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5 ml-1">E-mail</label>
          <input 
            type="email" 
            value={formData.email}
            onChange={(e) => setFormData({...formData, email: e.target.value})}
            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
          />
        </div>
        <div>
          <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Telefone</label>
          <input 
            type="tel" 
            value={formData.phone}
            onChange={(e) => setFormData({...formData, phone: e.target.value})}
            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
          />
        </div>
        <div className="sm:col-span-2">
          <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Localização</label>
          <input 
            type="text" 
            value={formData.location}
            onChange={(e) => setFormData({...formData, location: e.target.value})}
            placeholder="ex: São Paulo, SP"
            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
          />
        </div>
      </div>
      <div className="flex space-x-3 pt-4">
        <button 
          type="button" 
          onClick={onCancel}
          className="flex-1 py-3 text-slate-500 font-bold hover:bg-slate-50 rounded-2xl transition-all"
        >
          Cancelar
        </button>
        <button 
          type="submit" 
          disabled={loading}
          className="flex-1 py-3 bg-indigo-600 text-white font-bold rounded-2xl shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all disabled:opacity-50"
        >
          {loading ? 'Salvando...' : 'Salvar Contato'}
        </button>
      </div>
    </form>
  );
};

const NewGoalForm = ({ onSave, onCancel, token }: { onSave: (g: any) => void, onCancel: () => void, token: string }) => {
  const [formData, setFormData] = useState({
    title: '',
    target: '',
    deadline: ''
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/goals', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          ...formData,
          target: Number(formData.target),
          current: 0
        }),
      });
      if (res.ok) {
        const newGoal = await res.json();
        onSave(newGoal);
      }
    } catch (err) {
      console.error("Erro ao salvar meta:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Título da Meta</label>
          <input 
            type="text" 
            required
            value={formData.title}
            onChange={(e) => setFormData({...formData, title: e.target.value})}
            placeholder="ex: Meta de Vendas Mensal"
            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
          />
        </div>
        <div>
          <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Valor Alvo (R$)</label>
          <input 
            type="number" 
            required
            value={formData.target}
            onChange={(e) => setFormData({...formData, target: e.target.value})}
            placeholder="ex: 50000"
            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
          />
        </div>
        <div>
          <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Prazo Final</label>
          <input 
            type="date" 
            required
            value={formData.deadline}
            onChange={(e) => setFormData({...formData, deadline: e.target.value})}
            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
          />
        </div>
      </div>
      <div className="flex space-x-3 pt-4">
        <button 
          type="button" 
          onClick={onCancel}
          className="flex-1 py-3 text-slate-500 font-bold hover:bg-slate-50 rounded-2xl transition-all"
        >
          Cancelar
        </button>
        <button 
          type="submit" 
          disabled={loading}
          className="flex-1 py-3 bg-indigo-600 text-white font-bold rounded-2xl shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all disabled:opacity-50"
        >
          {loading ? 'Salvando...' : 'Criar Meta'}
        </button>
      </div>
    </form>
  );
};

const SidebarItem = ({ icon: Icon, label, active, onClick, desktop }: { icon: any, label: string, active?: boolean, onClick: () => void, desktop?: boolean, key?: string }) => (
  <button 
    onClick={onClick}
    className={cn(
      "flex transition-all duration-200",
      desktop 
        ? "flex-row items-center space-x-3 px-4 py-3 w-full rounded-xl mb-1" 
        : "flex-col items-center p-3 w-full",
      active 
        ? (desktop ? "bg-indigo-50 text-indigo-600" : "text-indigo-600") 
        : (desktop ? "text-slate-500 hover:bg-slate-50 hover:text-indigo-500" : "text-slate-400 hover:text-indigo-500")
    )}
  >
    <Icon className={cn(desktop ? "w-5 h-5" : "w-6 h-6")} />
    <span className={cn(desktop ? "text-sm font-semibold" : "text-[10px] mt-1 font-medium")}>{label}</span>
  </button>
);

const Badge = ({ children, variant = 'default' }: { children: React.ReactNode, variant?: string }) => {
  const variants: Record<string, string> = {
    default: "bg-slate-100 text-slate-700",
    success: "bg-emerald-100 text-emerald-800",
    warning: "bg-amber-100 text-amber-800",
    danger: "bg-rose-100 text-rose-800",
    info: "bg-indigo-100 text-indigo-800",
    blue: "bg-blue-100 text-blue-800",
    green: "bg-green-100 text-green-800",
    orange: "bg-orange-100 text-orange-800",
    purple: "bg-purple-100 text-purple-800",
  };
  return (
    <span className={cn("px-2.5 py-0.5 inline-flex text-xs leading-5 font-semibold rounded-full whitespace-nowrap", variants[variant])}>
      {children}
    </span>
  );
};

// --- Pages ---

const Dashboard = ({ stats }: { stats: DashboardStats }) => {
  return (
    <div className="space-y-6 p-4 md:p-8 pb-24 md:pb-8 max-w-7xl mx-auto">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center space-x-4"
        >
          <div className="bg-indigo-50 p-4 rounded-xl">
            <TrendingUp className="w-6 h-6 text-indigo-600" />
          </div>
          <div>
            <p className="text-sm text-slate-500 font-medium">Valor Total</p>
            <h3 className="text-2xl font-bold text-slate-800">{stats.totalValue}</h3>
            <p className="text-xs text-emerald-500 font-semibold mt-1 flex items-center">
              <ArrowUpRight className="w-3 h-3 mr-1" /> {stats.totalValueGrowth} vs mês anterior
            </p>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center space-x-4"
        >
          <div className="bg-indigo-50 p-4 rounded-xl">
            <Users className="w-6 h-6 text-indigo-600" />
          </div>
          <div>
            <p className="text-sm text-slate-500 font-medium">Novos Leads</p>
            <h3 className="text-2xl font-bold text-slate-800">{stats.newLeads}</h3>
            <p className="text-xs text-indigo-500 font-semibold mt-1">Em constante crescimento</p>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center space-x-4 sm:col-span-2 lg:col-span-1"
        >
          <div className="bg-indigo-50 p-4 rounded-xl">
            <Target className="w-6 h-6 text-indigo-600" />
          </div>
          <div>
            <p className="text-sm text-slate-500 font-medium">Taxa de Conversão</p>
            <h3 className="text-2xl font-bold text-slate-800">{stats.conversionRate}</h3>
            <p className="text-xs text-rose-500 font-semibold mt-1 flex items-center">
              <ArrowDownRight className="w-3 h-3 mr-1" /> {stats.conversionRateTrend} vs meta mensal
            </p>
          </div>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart */}
        <motion.section 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 lg:col-span-2"
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-bold text-slate-800">Desempenho Mensal</h2>
            <select className="text-sm border-slate-200 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 bg-slate-50 px-3 py-1.5 outline-none">
              <option>Ano de 2023</option>
              <option>Ano de 2024</option>
            </select>
          </div>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.performanceData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 12, fill: '#94a3b8' }}
                  dy={10}
                />
                <YAxis hide />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="value" radius={[6, 6, 0, 0]}>
                  {stats.performanceData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={index === stats.performanceData.length - 1 ? '#4338ca' : '#818cf8'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-6 pt-4 border-t border-slate-50 flex justify-between items-center text-sm text-slate-500">
            <span>Melhor Mês: Junho</span>
            <span className="font-semibold text-indigo-600">R$ 45.200</span>
          </div>
        </motion.section>

        {/* Recent Activities */}
        <motion.section 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100"
        >
          <h2 className="text-lg font-bold text-slate-800 mb-6">Atividades Recentes</h2>
          <div className="space-y-6">
            {stats.recentActivities.map((activity) => (
              <div key={activity.id} className="flex items-start space-x-4 group">
                <div className={cn("w-2 h-2 mt-2 rounded-full shrink-0", 
                  activity.color === 'blue' ? 'bg-blue-500' : 
                  activity.color === 'green' ? 'bg-emerald-500' : 
                  activity.color === 'orange' ? 'bg-orange-500' : 'bg-slate-500'
                )} />
                <div className="flex-grow">
                  <p className="text-sm font-semibold text-slate-800 group-hover:text-indigo-600 transition-colors">{activity.title}</p>
                  <p className="text-xs text-slate-500">{activity.time} • {activity.user}</p>
                </div>
                <Badge variant={activity.color}>{activity.type}</Badge>
              </div>
            ))}
          </div>
          <button className="w-full mt-6 py-2.5 text-sm font-semibold text-indigo-600 border border-indigo-100 rounded-xl hover:bg-indigo-50 transition-all">
            Ver Todo Histórico
          </button>
        </motion.section>
      </div>
    </div>
  );
};

const GoalsView = ({ token, goals, onNewGoal }: { token: string, goals: any[], onNewGoal: () => void }) => {
  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-8 pb-24 md:pb-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Minhas Metas</h1>
          <p className="text-slate-500">Acompanhe seu progresso e objetivos de vendas.</p>
        </div>
        <button 
          onClick={onNewGoal}
          className="bg-indigo-600 text-white px-6 py-2.5 rounded-xl text-sm font-bold shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all"
        >
          Nova Meta
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {goals.length > 0 ? goals.map(goal => (
          <motion.div 
            key={goal.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100"
          >
            <div className="flex justify-between items-start mb-4">
              <h3 className="font-bold text-slate-800">{goal.title}</h3>
              <Badge variant={goal.current >= goal.target ? 'success' : 'info'}>
                {Math.round((goal.current / goal.target) * 100)}%
              </Badge>
            </div>
            <div className="space-y-4">
              <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.min((goal.current / goal.target) * 100, 100)}%` }}
                  className={cn("h-full rounded-full", goal.current >= goal.target ? 'bg-emerald-500' : 'bg-indigo-600')}
                />
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Progresso: <span className="font-bold text-slate-800">R$ {goal.current.toLocaleString()}</span></span>
                <span className="text-slate-500">Meta: <span className="font-bold text-slate-800">R$ {goal.target.toLocaleString()}</span></span>
              </div>
              <div className="pt-4 border-t border-slate-50 flex items-center text-xs text-slate-400">
                <Clock className="w-3 h-3 mr-1" /> Prazo: {goal.deadline}
              </div>
            </div>
          </motion.div>
        )) : (
          <div className="col-span-full p-12 text-center bg-white rounded-3xl border border-dashed border-slate-200 text-slate-400">
            Nenhuma meta cadastrada ainda.
          </div>
        )}
      </div>
    </div>
  );
};

const ContactList = ({ contacts, onSelect, onNewContact, searchQuery, onSearchChange }: { contacts: Contact[], onSelect: (c: Contact) => void, onNewContact: () => void, searchQuery: string, onSearchChange: (q: string) => void }) => {
  return (
    <div className="flex flex-col h-full bg-white pb-24 md:pb-0 max-w-7xl mx-auto">
      <header className="p-4 md:p-8 border-b border-slate-100 bg-white sticky top-0 z-10">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <h1 className="text-2xl font-bold text-slate-800">Meus Contatos</h1>
          <button 
            onClick={onNewContact}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2.5 rounded-xl text-sm font-semibold transition-all flex items-center justify-center gap-2 shadow-sm shadow-indigo-200"
          >
            <Plus className="w-4 h-4" />
            Novo Contato
          </button>
        </div>
        <div className="relative max-w-md">
          <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="w-5 h-5 text-slate-400" />
          </span>
          <input 
            type="text" 
            placeholder="Buscar por nome ou empresa..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="block w-full pl-10 pr-3 py-3 border border-slate-200 rounded-2xl leading-5 bg-slate-50 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm transition-all"
          />
        </div>
      </header>

      <div className="flex-grow overflow-x-auto custom-scrollbar">
        <table className="min-w-full divide-y divide-slate-100">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-6 py-4 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Contato</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider hidden sm:table-cell">Empresa</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">Status</th>
              <th className="px-6 py-4 text-right text-xs font-semibold text-slate-500 uppercase tracking-wider">Ações</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-slate-50">
            {contacts.map((contact) => (
              <tr 
                key={contact.id} 
                onClick={() => onSelect(contact)}
                className="hover:bg-slate-50 transition-colors cursor-pointer group"
              >
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 h-12 w-12 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-700 font-bold group-hover:scale-110 transition-transform">
                      {contact.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-bold text-slate-900">{contact.name}</div>
                      <div className="text-xs text-indigo-600 mt-0.5 font-medium">{contact.phone}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap hidden sm:table-cell">
                  <div className="text-sm text-slate-600">{contact.company}</div>
                  <div className="text-xs text-slate-400">{contact.role}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <Badge variant={contact.status === 'Cliente Ativo' ? 'success' : contact.status === 'Em Negociação' ? 'warning' : 'default'}>
                    {contact.status}
                  </Badge>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <button className="text-slate-400 hover:text-indigo-600 p-2 rounded-lg hover:bg-white transition-all">
                    <MoreVertical className="w-5 h-5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const ContactDetails = ({ contact, onBack }: { contact: Contact, onBack: () => void, key?: string }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      className="flex flex-col h-full bg-slate-50 pb-24 md:pb-0"
    >
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10 px-4 md:px-8 py-6 shadow-sm">
        <div className="flex items-center space-x-4 max-w-7xl mx-auto w-full">
          <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
            <ChevronRight className="w-6 h-6 rotate-180" />
          </button>
          <div className="w-16 h-16 rounded-full bg-indigo-600 flex items-center justify-center text-white text-2xl font-bold shadow-lg shadow-indigo-200">
            {contact.name.split(' ').map(n => n[0]).join('')}
          </div>
          <div className="flex-1">
            <h1 className="text-xl md:text-2xl font-bold text-slate-900">{contact.name}</h1>
            <p className="text-sm text-slate-500">{contact.role} - {contact.company}</p>
          </div>
        </div>
      </header>

      <div className="flex-grow overflow-y-auto p-4 md:p-8 space-y-8 custom-scrollbar max-w-7xl mx-auto w-full">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1 space-y-6">
            {/* Contact Info Card */}
            <section className="bg-white rounded-2xl shadow-sm p-6 border border-slate-100">
              <h2 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-6">Informações de Contato</h2>
              <div className="space-y-5">
                <div className="flex items-center space-x-4 group">
                  <div className="p-3 bg-blue-50 rounded-xl text-blue-500 group-hover:bg-blue-500 group-hover:text-white transition-all">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[10px] text-slate-400 uppercase font-bold">E-mail</span>
                    <span className="text-sm text-slate-700 font-semibold">{contact.email}</span>
                  </div>
                </div>
                <div className="flex items-center space-x-4 group">
                  <div className="p-3 bg-emerald-50 rounded-xl text-emerald-500 group-hover:bg-emerald-500 group-hover:text-white transition-all">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[10px] text-slate-400 uppercase font-bold">Telefone</span>
                    <span className="text-sm text-slate-700 font-semibold">{contact.phone}</span>
                  </div>
                </div>
                <div className="flex items-center space-x-4 group">
                  <div className="p-3 bg-rose-50 rounded-xl text-rose-500 group-hover:bg-rose-500 group-hover:text-white transition-all">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[10px] text-slate-400 uppercase font-bold">Localização</span>
                    <span className="text-sm text-slate-700 font-semibold">{contact.location}</span>
                  </div>
                </div>
              </div>
            </section>

            {/* Tasks Section */}
            <section>
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Tarefas Pendentes</h2>
                <button className="text-indigo-600 text-xs font-bold hover:underline">+ Nova Tarefa</button>
              </div>
              <div className="space-y-3">
                {contact.tasks.length > 0 ? contact.tasks.map(task => (
                  <div key={task.id} className={cn(
                    "bg-white p-4 rounded-2xl shadow-sm border-l-4 flex justify-between items-center transition-all hover:translate-x-1",
                    task.status === 'overdue' ? 'border-rose-400' : 'border-orange-400'
                  )}>
                    <div>
                      <h3 className="text-sm font-semibold text-slate-800">{task.title}</h3>
                      <p className={cn("text-xs flex items-center mt-1", 
                        task.status === 'overdue' ? 'text-rose-500 font-medium' : 'text-slate-500'
                      )}>
                        <Clock className="w-3 h-3 mr-1" /> {task.dueDate}
                      </p>
                    </div>
                    <input type="checkbox" className="rounded-lg border-slate-300 text-indigo-600 focus:ring-indigo-500 h-5 w-5 cursor-pointer" />
                  </div>
                )) : (
                  <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 text-center">
                    <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                    <p className="text-sm text-slate-500">Nenhuma tarefa pendente</p>
                  </div>
                )}
              </div>
            </section>
          </div>

          <div className="lg:col-span-2">
            {/* History Section */}
            <section>
              <h2 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-6">Histórico de Interações</h2>
              <div className="relative border-l-2 border-slate-200 ml-4 pl-8 space-y-8">
                {contact.history.map(item => (
                  <div key={item.id} className="relative">
                    <div className={cn(
                      "absolute -left-[45px] mt-1 w-10 h-10 rounded-full flex items-center justify-center border-4 border-slate-50 shadow-sm transition-transform hover:scale-110",
                      item.type === 'note' ? 'bg-blue-100 text-blue-600' : 
                      item.type === 'email' ? 'bg-purple-100 text-purple-600' : 
                      'bg-emerald-100 text-emerald-600'
                    )}>
                      {item.type === 'note' ? <FileText className="w-5 h-4" /> : 
                       item.type === 'email' ? <Mail className="w-5 h-4" /> : 
                       <Phone className="w-5 h-4" />}
                    </div>
                    <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 hover:border-indigo-100 transition-all hover:shadow-md">
                      <div className="flex justify-between items-center mb-3">
                        <span className="text-sm font-bold text-slate-900">{item.title}</span>
                        <span className="text-xs text-slate-400 font-medium">{item.date}</span>
                      </div>
                      <p className="text-sm text-slate-600 leading-relaxed">{item.content}</p>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

// --- Main App ---

export default function App() {
  const [auth, setAuth] = useState<{ token: string, user: any } | null>(() => {
    const saved = localStorage.getItem('crm_auth');
    return saved ? JSON.parse(saved) : null;
  });
  const [authView, setAuthView] = useState<'login' | 'register'>('login');
  const [activeTab, setActiveTab] = useState<'dashboard' | 'contacts' | 'metas' | 'settings'>('dashboard');
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [goals, setGoals] = useState<any[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [messages, setMessages] = useState<any[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showMessages, setShowMessages] = useState(false);
  const [showNewContactModal, setShowNewContactModal] = useState(false);
  const [showNewGoalModal, setShowNewGoalModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [settingsModal, setSettingsModal] = useState<{ isOpen: boolean, title: string } | null>(null);
  const [loading, setLoading] = useState(false);

  const fetchData = async () => {
    if (!auth) return;
    setLoading(true);
    try {
      const headers = { 'Authorization': `Bearer ${auth.token}` };
      const [statsRes, contactsRes, notifRes, goalsRes, messagesRes] = await Promise.all([
        fetch('/api/dashboard', { headers }),
        fetch('/api/contacts', { headers }),
        fetch('/api/notifications', { headers }),
        fetch('/api/goals', { headers }),
        fetch('/api/messages', { headers })
      ]);

      if (statsRes.status === 401 || contactsRes.status === 401) {
        handleLogout();
        return;
      }

      const statsData = await statsRes.json();
      const contactsData = await contactsRes.json();
      const notifData = await notifRes.json();
      const goalsData = await goalsRes.json();
      const messagesData = await messagesRes.json();
      setStats(statsData);
      setContacts(contactsData);
      setNotifications(notifData);
      setGoals(goalsData);
      setMessages(messagesData);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [auth]);

  const markNotificationsRead = async () => {
    if (!auth) return;
    try {
      await fetch('/api/notifications/read', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${auth.token}` }
      });
      setNotifications(notifications.map(n => ({ ...n, isRead: 1 })));
    } catch (err) {
      console.error("Erro ao ler notificações:", err);
    }
  };

  const handleLogin = (token: string, user: any) => {
    const authData = { token, user };
    setAuth(authData);
    localStorage.setItem('crm_auth', JSON.stringify(authData));
  };

  const handleLogout = () => {
    setAuth(null);
    localStorage.removeItem('crm_auth');
    setActiveTab('dashboard');
    setSelectedContact(null);
  };

  if (!auth) {
    return authView === 'login' ? (
      <Login onLogin={handleLogin} onSwitchToRegister={() => setAuthView('register')} />
    ) : (
      <Register onRegisterSuccess={() => setAuthView('login')} onSwitchToLogin={() => setAuthView('login')} />
    );
  }

  if (loading && !stats) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-slate-50">
        <div className="flex flex-col items-center space-y-4">
          <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-slate-500 font-medium animate-pulse">Carregando CRM Pro...</p>
        </div>
      </div>
    );
  }

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'contacts', label: 'Contatos', icon: Users },
    { id: 'metas', label: 'Metas', icon: Target },
    { id: 'settings', label: 'Ajustes', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row relative">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 bg-white border-r border-slate-200 sticky top-0 h-screen z-40">
        <div className="p-6 border-b border-slate-100">
          <div className="flex items-center space-x-3">
            <div className="bg-indigo-600 p-2 rounded-xl">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-lg font-bold tracking-tight text-slate-900">Gestão de Vendas</h1>
          </div>
        </div>
        
        <nav className="flex-grow p-4 space-y-1">
          {navItems.map((item) => (
            <SidebarItem 
              key={item.id}
              icon={item.icon}
              label={item.label}
              active={activeTab === item.id && !selectedContact}
              onClick={() => { 
                setActiveTab(item.id as any); 
                setSelectedContact(null); 
              }}
              desktop
            />
          ))}
        </nav>

        <div className="p-4 border-t border-slate-100">
          <div className="flex items-center justify-between p-2">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full bg-indigo-500 border-2 border-white flex items-center justify-center font-bold text-sm text-white shadow-sm">
                {auth.user.username.substring(0, 2).toUpperCase()}
              </div>
              <div className="flex flex-col">
                <span className="text-sm font-bold text-slate-900">{auth.user.username}</span>
                <span className="text-xs text-slate-500">Administrador</span>
              </div>
            </div>
            <button 
              onClick={handleLogout}
              className="p-2 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-all"
              title="Sair"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-grow flex flex-col min-h-screen overflow-hidden">
        {/* Mobile/Tablet Header */}
        {activeTab === 'dashboard' && !selectedContact && (
          <header className="md:hidden bg-indigo-700 text-white p-4 shadow-lg flex items-center justify-between z-20">
            <div className="flex items-center space-x-3">
              <div className="bg-white/20 p-2 rounded-xl backdrop-blur-md">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-xl font-bold tracking-tight">Gestão de Vendas</h1>
            </div>
            <div className="flex items-center space-x-3">
              <button 
                onClick={() => setShowMessages(!showMessages)}
                className="p-2 hover:bg-white/10 rounded-full transition-colors relative"
              >
                <MessageSquare className="w-6 h-6" />
                {messages.some(m => !m.isRead) && (
                  <span className="absolute top-2 right-2 w-2 h-2 bg-indigo-400 rounded-full border-2 border-indigo-700" />
                )}
              </button>
              <button 
                onClick={() => {
                  setShowNotifications(!showNotifications);
                  if (!showNotifications) markNotificationsRead();
                }}
                className="p-2 hover:bg-white/10 rounded-full transition-colors relative"
              >
                <Bell className="w-6 h-6" />
                {notifications.some(n => !n.isRead) && (
                  <span className="absolute top-2 right-2 w-2 h-2 bg-rose-500 rounded-full border-2 border-indigo-700" />
                )}
              </button>
              <div className="w-10 h-10 rounded-full bg-indigo-500 border-2 border-white/30 flex items-center justify-center font-bold text-sm shadow-inner">
                {auth.user.username.substring(0, 2).toUpperCase()}
              </div>
            </div>
          </header>
        )}

        {/* Desktop Header (Global Search/Notifications) */}
        <header className="hidden md:flex bg-white h-16 border-b border-slate-200 items-center justify-between px-8 z-30">
          <div className="relative w-96">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Pesquisar..." 
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                if (activeTab !== 'contacts') setActiveTab('contacts');
              }}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
            />
          </div>
          <div className="flex items-center space-x-4">
            <div className="relative">
              <button 
                onClick={() => {
                  setShowNotifications(!showNotifications);
                  if (!showNotifications) markNotificationsRead();
                }}
                className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all relative"
              >
                <Bell className="w-5 h-5" />
                {notifications.some(n => !n.isRead) && (
                  <span className="absolute top-2 right-2 w-2 h-2 bg-rose-500 rounded-full border-2 border-white" />
                )}
              </button>
              
              <AnimatePresence>
                {showNotifications && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-2xl border border-slate-100 z-50 overflow-hidden"
                  >
                    <div className="p-4 border-b border-slate-50 flex justify-between items-center">
                      <h3 className="font-bold text-slate-800">Notificações</h3>
                      <button onClick={() => setShowNotifications(false)} className="text-xs text-slate-400 hover:text-slate-600">Fechar</button>
                    </div>
                    <div className="max-h-96 overflow-y-auto custom-scrollbar">
                      {notifications.length > 0 ? notifications.map(n => (
                        <div key={n.id} className={cn("p-4 border-b border-slate-50 hover:bg-slate-50 transition-colors", !n.isRead && "bg-indigo-50/30")}>
                          <p className="text-sm font-bold text-slate-800">{n.title}</p>
                          <p className="text-xs text-slate-500 mt-1">{n.message}</p>
                          <p className="text-[10px] text-slate-400 mt-2">{n.time}</p>
                        </div>
                      )) : (
                        <div className="p-8 text-center text-slate-400 text-sm">Nenhuma notificação</div>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            <div className="relative">
              <button 
                onClick={() => setShowMessages(!showMessages)}
                className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all relative"
              >
                <MessageSquare className="w-5 h-5" />
                {messages.some(m => !m.isRead) && (
                  <span className="absolute top-2 right-2 w-2 h-2 bg-indigo-500 rounded-full border-2 border-white" />
                )}
              </button>

              <AnimatePresence>
                {showMessages && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    className="absolute right-0 mt-2 w-96 bg-white rounded-2xl shadow-2xl border border-slate-100 z-50 overflow-hidden"
                  >
                    <div className="p-4 border-b border-slate-50 flex justify-between items-center bg-indigo-600 text-white">
                      <h3 className="font-bold">Comentários e Suporte</h3>
                      <button onClick={() => setShowMessages(false)} className="text-xs opacity-70 hover:opacity-100">Fechar</button>
                    </div>
                    <div className="h-80 overflow-y-auto p-4 space-y-4 custom-scrollbar bg-slate-50">
                      {messages.length > 0 ? [...messages].reverse().map(m => (
                        <div key={m.id} className={cn("flex flex-col max-w-[80%]", m.sender === 'Você' ? "ml-auto items-end" : "mr-auto items-start")}>
                          <div className={cn("p-3 rounded-2xl text-sm shadow-sm", m.sender === 'Você' ? "bg-indigo-600 text-white rounded-tr-none" : "bg-white text-slate-800 rounded-tl-none")}>
                            {m.content}
                          </div>
                          <span className="text-[10px] text-slate-400 mt-1">{m.sender} • {m.time}</span>
                        </div>
                      )) : (
                        <div className="h-full flex items-center justify-center text-slate-400 text-sm italic">Sem mensagens</div>
                      )}
                    </div>
                    <form 
                      onSubmit={async (e) => {
                        e.preventDefault();
                        const form = e.target as HTMLFormElement;
                        const input = form.elements.namedItem('message') as HTMLInputElement;
                        if (!input.value.trim()) return;
                        
                        const content = input.value;
                        input.value = '';
                        
                        try {
                          const res = await fetch('/api/messages', {
                            method: 'POST',
                            headers: { 
                              'Authorization': `Bearer ${auth.token}`,
                              'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({ content })
                          });
                          const newMsg = await res.json();
                          setMessages([...messages, newMsg]);
                          
                          // Mock auto-reply refresh after 2s
                          setTimeout(fetchData, 2500);
                        } catch (err) {
                          console.error("Erro ao enviar mensagem:", err);
                        }
                      }}
                      className="p-3 border-t border-slate-100 bg-white flex gap-2"
                    >
                      <input 
                        name="message"
                        type="text" 
                        placeholder="Escreva um comentário..." 
                        className="flex-grow text-sm p-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                      <button type="submit" className="bg-indigo-600 text-white p-2 rounded-xl hover:bg-indigo-700 transition-all">
                        <Send className="w-4 h-4" />
                      </button>
                    </form>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </header>

        <main className="flex-grow overflow-hidden">
          <AnimatePresence mode="wait">
            {selectedContact ? (
              <ContactDetails 
                key="details"
                contact={selectedContact} 
                onBack={() => setSelectedContact(null)} 
              />
            ) : (
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.2 }}
                className="h-full overflow-y-auto custom-scrollbar"
              >
                {activeTab === 'dashboard' && stats && <Dashboard stats={stats} />}
                {activeTab === 'contacts' && (
                  <ContactList 
                    contacts={contacts.filter(c => 
                      c.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                      c.company.toLowerCase().includes(searchQuery.toLowerCase())
                    )} 
                    onSelect={setSelectedContact} 
                    onNewContact={() => setShowNewContactModal(true)}
                    searchQuery={searchQuery}
                    onSearchChange={setSearchQuery}
                  />
                )}
                {activeTab === 'metas' && (
                  <GoalsView 
                    token={auth.token} 
                    goals={goals} 
                    onNewGoal={() => setShowNewGoalModal(true)} 
                  />
                )}
                {activeTab === 'settings' && (
                  <div className="p-8 md:p-12 max-w-4xl mx-auto space-y-8 pb-24 md:pb-8">
                    <div className="flex items-center space-x-6">
                      <div className="w-24 h-24 bg-indigo-100 rounded-3xl flex items-center justify-center shadow-inner">
                        <Settings className="w-12 h-12 text-indigo-600" />
                      </div>
                      <div>
                        <h2 className="text-2xl font-bold text-slate-800">Configurações</h2>
                        <p className="text-slate-500">Gerencie sua conta e preferências do sistema.</p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {[
                        { label: 'Perfil do Usuário', desc: 'Edite suas informações pessoais' },
                        { label: 'Notificações', desc: 'Configure como deseja ser avisado' },
                        { label: 'Segurança e Senha', desc: 'Mantenha sua conta protegida' },
                        { label: 'Integrações de API', desc: 'Conecte outras ferramentas' },
                        { label: 'Faturamento', desc: 'Gerencie seu plano e faturas' },
                        { label: 'Centro de Ajuda', desc: 'Suporte e documentação' }
                      ].map(item => (
                        <button 
                          key={item.label} 
                          onClick={() => setSettingsModal({ isOpen: true, title: item.label })}
                          className="p-6 bg-white rounded-3xl border border-slate-100 flex flex-col text-left hover:border-indigo-200 hover:shadow-md transition-all group"
                        >
                          <div className="flex justify-between items-center mb-2">
                            <span className="font-bold text-slate-800 group-hover:text-indigo-600">{item.label}</span>
                            <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-1 transition-all" />
                          </div>
                          <span className="text-xs text-slate-500">{item.desc}</span>
                        </button>
                      ))}
                      <button 
                        onClick={handleLogout}
                        className="p-6 bg-rose-50 rounded-3xl border border-rose-100 flex justify-between items-center hover:bg-rose-100 transition-all group md:col-span-2"
                      >
                        <div className="flex flex-col">
                          <span className="font-bold text-rose-700">Sair da Conta</span>
                          <span className="text-xs text-rose-500">Encerrar sua sessão atual com segurança</span>
                        </div>
                        <LogOut className="w-6 h-6 text-rose-500" />
                      </button>
                    </div>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </main>
      </div>

      {/* Modals */}
      <Modal 
        isOpen={showNewContactModal} 
        onClose={() => setShowNewContactModal(false)}
        title="Novo Contato"
      >
        <NewContactForm 
          token={auth.token}
          onCancel={() => setShowNewContactModal(false)}
          onSave={(newContact) => {
            setContacts([newContact, ...contacts]);
            setShowNewContactModal(false);
          }}
        />
      </Modal>

      <Modal 
        isOpen={showNewGoalModal} 
        onClose={() => setShowNewGoalModal(false)}
        title="Nova Meta"
      >
        <NewGoalForm 
          token={auth.token}
          onCancel={() => setShowNewGoalModal(false)}
          onSave={(newGoal) => {
            setGoals([newGoal, ...goals]);
            setShowNewGoalModal(false);
          }}
        />
      </Modal>

      <Modal 
        isOpen={!!settingsModal?.isOpen} 
        onClose={() => setSettingsModal(null)}
        title={settingsModal?.title || 'Configurações'}
      >
        {settingsModal?.title === 'Perfil do Usuário' && (
          <form 
            onSubmit={async (e) => {
              e.preventDefault();
              const formData = new FormData(e.target as HTMLFormElement);
              const data = Object.fromEntries(formData);
              try {
                const res = await fetch('/api/user/profile', {
                  method: 'PUT',
                  headers: { 
                    'Authorization': `Bearer ${auth.token}`,
                    'Content-Type': 'application/json'
                  },
                  body: JSON.stringify(data)
                });
                const result = await res.json();
                if (result.success) {
                  setAuth({ ...auth, user: result.user });
                  setSettingsModal(null);
                }
              } catch (err) {
                console.error("Erro ao salvar perfil:", err);
              }
            }}
            className="space-y-4 p-2"
          >
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Nome de Usuário</label>
              <input name="username" defaultValue={auth.user.username} className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none" required />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">E-mail</label>
              <input name="email" type="email" defaultValue={auth.user.email} className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none" required />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Telefone</label>
              <input name="phone" defaultValue={auth.user.phone} className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none" />
            </div>
            <button type="submit" className="w-full py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-all">Salvar Alterações</button>
          </form>
        )}

        {settingsModal?.title === 'Segurança e Senha' && (
          <form 
            onSubmit={async (e) => {
              e.preventDefault();
              const formData = new FormData(e.target as HTMLFormElement);
              const data = Object.fromEntries(formData);
              if (data.newPassword !== data.confirmPassword) {
                alert("As senhas não coincidem!");
                return;
              }
              try {
                const res = await fetch('/api/user/password', {
                  method: 'PUT',
                  headers: { 
                    'Authorization': `Bearer ${auth.token}`,
                    'Content-Type': 'application/json'
                  },
                  body: JSON.stringify({
                    currentPassword: data.currentPassword,
                    newPassword: data.newPassword
                  })
                });
                const result = await res.json();
                if (result.success) {
                  alert("Senha atualizada com sucesso!");
                  setSettingsModal(null);
                } else {
                  alert(result.error);
                }
              } catch (err) {
                console.error("Erro ao salvar senha:", err);
              }
            }}
            className="space-y-4 p-2"
          >
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Senha Atual</label>
              <input name="currentPassword" type="password" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none" required />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Nova Senha</label>
              <input name="newPassword" type="password" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none" required />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Confirmar Nova Senha</label>
              <input name="confirmPassword" type="password" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none" required />
            </div>
            <button type="submit" className="w-full py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-all">Atualizar Senha</button>
          </form>
        )}

        {['Notificações', 'Integrações de API', 'Faturamento', 'Centro de Ajuda'].includes(settingsModal?.title || '') && (
          <div className="p-4 text-center space-y-4">
            <div className="w-16 h-16 bg-indigo-50 rounded-full flex items-center justify-center mx-auto">
              <Settings className="w-8 h-8 text-indigo-600" />
            </div>
            <p className="text-slate-600">
              A funcionalidade de <strong>{settingsModal?.title}</strong> está sendo preparada para o seu perfil.
            </p>
            <p className="text-sm text-slate-400 italic">
              Em breve você poderá gerenciar todos os detalhes desta seção.
            </p>
            <button 
              onClick={() => setSettingsModal(null)}
              className="w-full py-3 bg-slate-100 text-slate-600 font-bold rounded-2xl hover:bg-slate-200 transition-all"
            >
              Entendido
            </button>
          </div>
        )}
      </Modal>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-xl border-t border-slate-100 p-2 flex justify-around items-center z-50 shadow-[0_-4px_20px_rgba(0,0,0,0.03)]">
        {navItems.map((item) => (
          <SidebarItem 
            key={item.id}
            icon={item.icon}
            label={item.label}
            active={activeTab === item.id && !selectedContact}
            onClick={() => { 
              setActiveTab(item.id as any); 
              setSelectedContact(null); 
            }}
          />
        ))}
      </nav>
    </div>
  );
}
