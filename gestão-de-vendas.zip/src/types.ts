export interface Task {
  id: string;
  title: string;
  dueDate: string;
  status: 'pending' | 'completed' | 'overdue';
  priority: 'low' | 'medium' | 'high' | 'critical';
}

export interface HistoryItem {
  id: string;
  type: 'note' | 'email' | 'call';
  title: string;
  date: string;
  content: string;
}

export interface Contact {
  id: string;
  name: string;
  company: string;
  phone: string;
  email: string;
  status: string;
  role: string;
  location: string;
  tasks: Task[];
  history: HistoryItem[];
}

export interface DashboardStats {
  totalValue: string;
  totalValueGrowth: string;
  newLeads: number;
  conversionRate: string;
  conversionRateTrend: string;
  performanceData: { name: string; value: number }[];
  recentActivities: {
    id: string;
    type: string;
    title: string;
    time: string;
    user: string;
    color: string;
  }[];
}
