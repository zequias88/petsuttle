import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const JWT_SECRET = process.env.JWT_SECRET || "fallback-secret-for-dev";

// Initialize Database
const db = new Database("crm.db");

// Create Tables
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    username TEXT UNIQUE NOT NULL,
    phone TEXT,
    password TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS contacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    company TEXT,
    phone TEXT,
    email TEXT,
    status TEXT DEFAULT 'Lead',
    role TEXT,
    location TEXT,
    userId INTEGER,
    FOREIGN KEY(userId) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS contact_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    contactId INTEGER,
    type TEXT,
    title TEXT,
    date TEXT,
    content TEXT,
    FOREIGN KEY(contactId) REFERENCES contacts(id)
  );

  CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    contactId INTEGER,
    title TEXT,
    dueDate TEXT,
    status TEXT,
    priority TEXT,
    FOREIGN KEY(contactId) REFERENCES contacts(id)
  );

  CREATE TABLE IF NOT EXISTS goals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    target REAL,
    current REAL,
    deadline TEXT,
    userId INTEGER,
    FOREIGN KEY(userId) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    message TEXT,
    time TEXT,
    isRead INTEGER DEFAULT 0,
    userId INTEGER,
    FOREIGN KEY(userId) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    userId INTEGER,
    sender TEXT,
    content TEXT,
    time TEXT,
    isRead INTEGER DEFAULT 0,
    FOREIGN KEY(userId) REFERENCES users(id)
  );
`);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Auth Middleware
  const authenticateToken = (req: any, res: any, next: any) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) return res.status(401).json({ error: "Unauthorized" });

    jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
      if (err) return res.status(403).json({ error: "Forbidden" });
      req.user = user;
      next();
    });
  };

  // Auth Routes
  app.post("/api/auth/register", async (req, res) => {
    const { email, username, phone, password } = req.body;
    try {
      const hashedPassword = await bcrypt.hash(password, 10);
      const stmt = db.prepare("INSERT INTO users (email, username, phone, password) VALUES (?, ?, ?, ?)");
      const info = stmt.run(email, username, phone, hashedPassword);
      
      const userId = info.lastInsertRowid;
      
      // Seed initial data for new user
      const contactStmt = db.prepare("INSERT INTO contacts (name, company, phone, email, status, role, location, userId) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
      const c1 = contactStmt.run("João Silva", "Tech Inovações", "(11) 98877-6655", "joao.silva@techinova.com.br", "Cliente Ativo", "Gerente de TI", "São Paulo, SP", userId);
      const c2 = contactStmt.run("Maria Almeida", "Logística BR", "(21) 97766-5544", "maria.almeida@logbr.com.br", "Em Negociação", "Diretora Comercial", "Rio de Janeiro, RJ", userId);
      
      const historyStmt = db.prepare("INSERT INTO contact_history (contactId, type, title, date, content) VALUES (?, ?, ?, ?, ?)");
      historyStmt.run(c1.lastInsertRowid, "note", "Nota Interna", "14 Out, 14:20", "Cliente demonstrou interesse no novo módulo de logística.");
      
      const goalStmt = db.prepare("INSERT INTO goals (title, target, current, deadline, userId) VALUES (?, ?, ?, ?, ?)");
      goalStmt.run("Meta de Vendas Q1", 100000, 65000, "2026-03-31", userId);
      goalStmt.run("Novos Clientes", 20, 12, "2026-03-31", userId);

      const notifStmt = db.prepare("INSERT INTO notifications (title, message, time, userId) VALUES (?, ?, ?, ?)");
      notifStmt.run("Bem-vindo!", "Sua conta foi criada com sucesso.", "Agora", userId);

      const msgStmt = db.prepare("INSERT INTO messages (userId, sender, content, time) VALUES (?, ?, ?, ?)");
      msgStmt.run(userId, "Suporte CRM", "Olá! Seja bem-vindo ao Gestão de Vendas. Como podemos ajudar hoje?", "Agora");

      res.json({ success: true, userId });
    } catch (error: any) {
      if (error.message.includes("UNIQUE constraint failed")) {
        res.status(400).json({ error: "E-mail ou Usuário já cadastrado." });
      } else {
        res.status(500).json({ error: "Erro ao cadastrar usuário." });
      }
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    const { identifier, password } = req.body; // identifier can be email or username
    try {
      const user: any = db.prepare("SELECT * FROM users WHERE email = ? OR username = ?").get(identifier, identifier);
      if (!user) return res.status(400).json({ error: "Usuário não encontrado." });

      const validPassword = await bcrypt.compare(password, user.password);
      if (!validPassword) return res.status(400).json({ error: "Senha incorreta." });

      const token = jwt.sign({ id: user.id, email: user.email, username: user.username }, JWT_SECRET, { expiresIn: '24h' });
      res.json({ token, user: { id: user.id, email: user.email, username: user.username, phone: user.phone } });
    } catch (error) {
      res.status(500).json({ error: "Erro ao fazer login." });
    }
  });

  // Mock Data
  const contacts = [
    {
      id: "1",
      name: "João Silva",
      company: "Tech Inovações",
      phone: "(11) 98877-6655",
      email: "joao.silva@techinova.com.br",
      status: "Cliente Ativo",
      role: "Gerente de TI",
      location: "São Paulo, SP",
      tasks: [
        { id: "t1", title: "Enviar proposta comercial", dueDate: "Amanhã", status: "pending", priority: "high" }
      ],
      history: [
        { id: "h1", type: "note", title: "Nota Interna", date: "14 Out, 14:20", content: "Cliente demonstrou interesse no novo módulo de logística." },
        { id: "h2", type: "email", title: "E-mail Enviado", date: "12 Out, 09:45", content: "Assunto: Seguimento da Reunião Mensal. Anexei os relatórios solicitados." }
      ]
    },
    {
      id: "2",
      name: "Maria Almeida",
      company: "Logística BR",
      phone: "(21) 97766-5544",
      email: "maria.almeida@logbr.com.br",
      status: "Em Negociação",
      role: "Diretora Comercial",
      location: "Rio de Janeiro, RJ",
      tasks: [],
      history: []
    },
    {
      id: "3",
      name: "Ricardo Cavalcanti",
      company: "TechLog S.A.",
      phone: "(11) 98765-4321",
      email: "ricardo.cavalcanti@techlog.com.br",
      status: "Cliente Ativo",
      role: "Diretor de Operações",
      location: "São Paulo, SP",
      tasks: [
        { id: "t2", title: "Enviar proposta comercial", dueDate: "Amanhã", status: "pending", priority: "high" },
        { id: "t3", title: "Retornar ligação de suporte", dueDate: "Atrasado (2 dias)", status: "overdue", priority: "critical" }
      ],
      history: [
        { id: "h3", type: "note", title: "Nota Interna", date: "14 Out, 14:20", content: "Cliente demonstrou interesse no novo módulo de logística. Aguardando aprovação do orçamento." },
        { id: "h4", type: "email", title: "E-mail Enviado", date: "12 Out, 09:45", content: "Assunto: Seguimento da Reunião Mensal. Anexei os relatórios de performance solicitados na última segunda-feira..." },
        { id: "h5", type: "call", title: "Ligação Efetuada", date: "10 Out, 11:00", content: "Conversa rápida para alinhar as expectativas do projeto Q4. Cliente satisfeito com o progresso." }
      ]
    }
  ];

  const dashboardStats = {
    totalValue: "R$ 142.500,00",
    totalValueGrowth: "12%",
    newLeads: 342,
    conversionRate: "24.8%",
    conversionRateTrend: "-2%",
    performanceData: [
      { name: "Jan", value: 2400 },
      { name: "Fev", value: 3200 },
      { name: "Mar", value: 2000 },
      { name: "Abr", value: 4000 },
      { name: "Mai", value: 3600 },
      { name: "Jun", value: 4520 },
    ],
    recentActivities: [
      { id: "a1", type: "Vendas", title: 'Proposta enviada para "Tech Solutions LTDA"', time: "Há 15 minutos", user: "João Silva", color: "blue" },
      { id: "a2", type: "Lead", title: 'Novo Lead qualificado: "Marcos Oliveira"', time: "Há 1 hora", user: "Marketing Digital", color: "green" },
      { id: "a3", type: "Reunião", title: "Reunião de follow-up agendada", time: "Há 3 horas", user: "Construtora Alfa", color: "orange" },
      { id: "a4", type: "Fechamento", title: 'Contrato assinado: "Logística Express"', time: "Ontem às 17:30", user: "Valor: R$ 12.000", color: "blue" },
    ]
  };

  // Protected API Routes
  app.get("/api/contacts", authenticateToken, (req: any, res) => {
    try {
      const contacts = db.prepare("SELECT * FROM contacts WHERE userId = ?").all(req.user.id);
      res.json(contacts);
    } catch (error) {
      res.status(500).json({ error: "Erro ao buscar contatos." });
    }
  });

  app.post("/api/contacts", authenticateToken, (req: any, res) => {
    const { name, company, phone, email, status, role, location } = req.body;
    try {
      const stmt = db.prepare("INSERT INTO contacts (name, company, phone, email, status, role, location, userId) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
      const info = stmt.run(name, company, phone, email, status || 'Lead', role, location, req.user.id);
      res.json({ id: info.lastInsertRowid, name, company, phone, email, status: status || 'Lead', role, location });
    } catch (error) {
      res.status(500).json({ error: "Erro ao criar contato." });
    }
  });

  app.get("/api/contacts/:id", authenticateToken, (req: any, res) => {
    try {
      const contact: any = db.prepare("SELECT * FROM contacts WHERE id = ? AND userId = ?").get(req.params.id, req.user.id);
      if (contact) {
        contact.history = db.prepare("SELECT * FROM contact_history WHERE contactId = ?").all(contact.id);
        contact.tasks = db.prepare("SELECT * FROM tasks WHERE contactId = ?").all(contact.id);
        res.json(contact);
      } else {
        res.status(404).json({ error: "Contact not found" });
      }
    } catch (error) {
      res.status(500).json({ error: "Erro ao buscar detalhes do contato." });
    }
  });

  app.get("/api/dashboard", authenticateToken, (req: any, res) => {
    res.json(dashboardStats);
  });

  app.get("/api/goals", authenticateToken, (req: any, res) => {
    try {
      const goals = db.prepare("SELECT * FROM goals WHERE userId = ?").all(req.user.id);
      res.json(goals);
    } catch (error) {
      res.status(500).json({ error: "Erro ao buscar metas." });
    }
  });

  app.post("/api/goals", authenticateToken, (req: any, res) => {
    const { title, target, current, deadline } = req.body;
    try {
      const stmt = db.prepare("INSERT INTO goals (title, target, current, deadline, userId) VALUES (?, ?, ?, ?, ?)");
      const info = stmt.run(title, target, current || 0, deadline, req.user.id);
      res.json({ id: info.lastInsertRowid, title, target, current: current || 0, deadline });
    } catch (error) {
      res.status(500).json({ error: "Erro ao criar meta." });
    }
  });

  app.get("/api/notifications", authenticateToken, (req: any, res) => {
    try {
      const notifications = db.prepare("SELECT * FROM notifications WHERE userId = ? ORDER BY id DESC").all(req.user.id);
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ error: "Erro ao buscar notificações." });
    }
  });

  app.post("/api/notifications/read", authenticateToken, (req: any, res) => {
    try {
      db.prepare("UPDATE notifications SET isRead = 1 WHERE userId = ?").run(req.user.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Erro ao atualizar notificações." });
    }
  });

  // User Profile & Settings
  app.put("/api/user/profile", authenticateToken, (req: any, res) => {
    const { username, phone, email } = req.body;
    try {
      db.prepare("UPDATE users SET username = ?, phone = ?, email = ? WHERE id = ?").run(username, phone, email, req.user.id);
      res.json({ success: true, user: { id: req.user.id, username, phone, email } });
    } catch (error) {
      res.status(500).json({ error: "Erro ao atualizar perfil." });
    }
  });

  app.put("/api/user/password", authenticateToken, async (req: any, res) => {
    const { currentPassword, newPassword } = req.body;
    try {
      const user: any = db.prepare("SELECT password FROM users WHERE id = ?").get(req.user.id);
      const validPassword = await bcrypt.compare(currentPassword, user.password);
      if (!validPassword) return res.status(400).json({ error: "Senha atual incorreta." });

      const hashedNewPassword = await bcrypt.hash(newPassword, 10);
      db.prepare("UPDATE users SET password = ? WHERE id = ?").run(hashedNewPassword, req.user.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Erro ao atualizar senha." });
    }
  });

  // Messages
  app.get("/api/messages", authenticateToken, (req: any, res) => {
    try {
      const messages = db.prepare("SELECT * FROM messages WHERE userId = ? ORDER BY id DESC").all(req.user.id);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "Erro ao buscar mensagens." });
    }
  });

  app.post("/api/messages", authenticateToken, (req: any, res) => {
    const { content } = req.body;
    try {
      const stmt = db.prepare("INSERT INTO messages (userId, sender, content, time) VALUES (?, ?, ?, ?)");
      const info = stmt.run(req.user.id, "Você", content, "Agora");
      
      // Mock auto-reply
      setTimeout(() => {
        db.prepare("INSERT INTO messages (userId, sender, content, time) VALUES (?, ?, ?, ?)")
          .run(req.user.id, "Suporte CRM", "Recebemos seu comentário! Nossa equipe entrará em contato em breve.", "Agora");
      }, 2000);

      res.json({ id: info.lastInsertRowid, sender: "Você", content, time: "Agora" });
    } catch (error) {
      res.status(500).json({ error: "Erro ao enviar mensagem." });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
