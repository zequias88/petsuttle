import { motion, AnimatePresence } from "motion/react";
import { Home, Heart, Bell, User, Search, BellRing, LogOut, LogIn, CheckCircle2 } from "lucide-react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { cn } from "@/src/lib/utils";
import { useAuth } from "@/src/contexts/AuthContext";
import { useState, useEffect } from "react";

export function BottomNav() {
  const location = useLocation();
  const { user } = useAuth();
  
  const navItems = [
    { icon: Home, label: "Início", path: "/" },
    { icon: Heart, label: "Desejos", path: "/wishlist" },
    { icon: Bell, label: "Alertas", path: "/alerts" },
    { icon: User, label: user ? "Perfil" : "Clientes", path: "/profile" },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center py-2 px-6 shadow-2xl z-50">
      {navItems.map((item) => {
        const isActive = location.pathname === item.path;
        const Icon = item.icon;
        
        return (
          <Link
            key={item.path}
            to={item.path}
            className={cn(
              "flex flex-col items-center gap-1 transition-colors",
              isActive ? "text-blue-600" : "text-gray-400"
            )}
          >
            <Icon className={cn("h-6 w-6", isActive && "fill-current")} />
            <span className="text-[10px] font-bold uppercase">{item.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}

export function Header() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [showToast, setShowToast] = useState(false);

  const navItems = [
    { icon: Home, label: "Início", path: "/" },
    { icon: Heart, label: "Desejos", path: "/wishlist" },
    { icon: Bell, label: "Alertas", path: "/alerts" },
    { icon: User, label: user ? "Perfil" : "Clientes", path: "/profile" },
  ];

  useEffect(() => {
    if (showToast) {
      const timer = setTimeout(() => setShowToast(false), 3000);
      return () => clearTimeout(timer);
    }
  }, [showToast]);

  return (
    <header className="bg-blue-800 text-white p-4 sticky top-0 z-50 shadow-md">
      <div className="flex flex-col gap-4 max-w-7xl mx-auto">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-8">
            <Link to="/" className="text-2xl font-bold italic tracking-tight">
              Preço<span className="text-emerald-400">Baixo</span>
            </Link>
            
            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-6">
              {navItems.map((item) => (
                <Link 
                  key={item.path}
                  to={item.path}
                  className="text-sm font-bold uppercase tracking-wider hover:text-emerald-400 transition-colors"
                >
                  {item.label}
                </Link>
              ))}
            </nav>
          </div>

          <div className="flex items-center gap-3">
            <div className="relative hidden md:block w-64 lg:w-96">
              <input
                type="text"
                placeholder="Compare preços..."
                className="w-full py-2 px-4 pl-10 rounded-full text-gray-800 border-none focus:ring-2 focus:ring-emerald-400 outline-none shadow-inner text-sm"
              />
              <Search className="absolute left-3 top-2 h-4 w-4 text-gray-400" />
            </div>

            {user ? (
              <div className="flex items-center gap-3">
                <div className="text-right hidden sm:block">
                  <p className="text-[10px] font-bold opacity-70 uppercase">Olá,</p>
                  <p className="text-xs font-black">{user.name.split(' ')[0]}</p>
                </div>
                <button 
                  onClick={logout}
                  className="p-2 hover:bg-white/10 rounded-full transition-colors flex items-center gap-2"
                  title="Sair"
                >
                  <LogOut className="h-5 w-5" />
                </button>
              </div>
            ) : (
              <Link 
                to="/login"
                className="flex items-center gap-2 bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded-full transition-colors text-xs font-bold"
              >
                <LogIn className="h-4 w-4" />
                Entrar
              </Link>
            )}
            <button 
              onClick={() => setShowToast(true)}
              className="p-2 hover:bg-white/10 rounded-full transition-colors relative group"
            >
              <BellRing className="h-6 w-6" />
              <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-red-500 border-2 border-blue-800 rounded-full group-hover:animate-bounce"></span>
            </button>
          </div>
        </div>
        
        {/* Mobile Search */}
        <div className="relative md:hidden">
          <input
            type="text"
            placeholder="Compare preços de produtos..."
            className="w-full py-3 px-4 pl-10 rounded-full text-gray-800 border-none focus:ring-2 focus:ring-emerald-400 outline-none shadow-inner"
          />
          <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
        </div>
      </div>

      {/* Notification Toast */}
      <AnimatePresence>
        {showToast && (
          <motion.div
            initial={{ opacity: 0, y: -20, x: '-50%' }}
            animate={{ opacity: 1, y: 20, x: '-50%' }}
            exit={{ opacity: 0, y: -20, x: '-50%' }}
            className="fixed top-16 left-1/2 z-[60] bg-emerald-500 text-white px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3 border border-emerald-400"
          >
            <CheckCircle2 className="h-5 w-5" />
            <span className="text-sm font-black uppercase tracking-wide">Notificações ativadas com sucesso!</span>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

export function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-400 py-12 px-4 mt-auto border-t border-gray-800">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
        <div>
          <Link to="/" className="text-2xl font-bold italic tracking-tight text-white mb-4 block">
            Preço<span className="text-emerald-400">Baixo</span>
          </Link>
          <p className="text-sm leading-relaxed">
            O maior comparador de preços do Brasil. Economize tempo e dinheiro em todas as suas compras online.
          </p>
        </div>
        
        <div>
          <h4 className="text-white font-bold mb-4 uppercase tracking-widest text-xs">Links Rápidos</h4>
          <ul className="space-y-2 text-sm">
            <li><Link to="/" className="hover:text-emerald-400 transition-colors">Início</Link></li>
            <li><Link to="/wishlist" className="hover:text-emerald-400 transition-colors">Lista de Desejos</Link></li>
            <li><Link to="/alerts" className="hover:text-emerald-400 transition-colors">Alertas de Preço</Link></li>
            <li><Link to="/profile" className="hover:text-emerald-400 transition-colors">Minha Conta</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-white font-bold mb-4 uppercase tracking-widest text-xs">Contato e Localização</h4>
          <ul className="space-y-3 text-sm">
            <li className="flex items-start gap-2">
              <span className="text-emerald-400 font-bold">Endereço:</span>
              <span>Rua Gracina Cardoso do Santos, 65A - Vila Lafranchi, Franco da Rocha - SP</span>
            </li>
            <li className="flex items-center gap-2">
              <span className="text-emerald-400 font-bold">CNPJ:</span>
              <span>45.678.901/0001-23</span>
            </li>
            <li className="flex items-center gap-2">
              <span className="text-emerald-400 font-bold">Email:</span>
              <span>contato@precobaixo.com.br</span>
            </li>
          </ul>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto mt-12 pt-8 border-t border-gray-800 text-center text-xs">
        <p>&copy; {new Date().getFullYear()} PreçoBaixo Comparador de Preços Ltda. Todos os direitos reservados.</p>
      </div>
    </footer>
  );
}
