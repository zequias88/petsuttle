import React, { useState } from "react";
import { motion } from "motion/react";
import { UserPlus, ArrowLeft, CheckCircle2, User, Mail, Phone, LogIn, LogOut, Calendar, ShieldCheck, Lock } from "lucide-react";
import { useNavigate, Link } from "react-router-dom";
import { Customer } from "@/src/types";
import { useAuth } from "@/src/contexts/AuthContext";

export default function CustomerRegistrationPage() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newCustomer: Customer = {
      id: Math.random().toString(36).substr(2, 9),
      ...formData,
      createdAt: new Date().toISOString(),
    };
    
    const existing = JSON.parse(localStorage.getItem("customers") || "[]");
    localStorage.setItem("customers", JSON.stringify([...existing, newCustomer]));

    setIsSubmitted(true);
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({ name: "", email: "", phone: "", password: "" });
      navigate("/login");
    }, 2000);
  };

  if (user) {
    return (
      <div className="pb-24 bg-gray-50 min-h-screen max-w-7xl mx-auto">
        <header className="bg-white border-b sticky top-0 z-50 p-4 flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
            <ArrowLeft className="h-6 w-6" />
          </button>
          <h1 className="text-xl font-bold text-gray-800">Meu Perfil</h1>
        </header>

        <main className="max-w-md mx-auto p-6 md:pt-12">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8"
          >
            <div className="flex flex-col items-center mb-8">
              <div className="w-24 h-24 bg-blue-600 rounded-full flex items-center justify-center text-white text-3xl font-black mb-4 shadow-xl shadow-blue-600/20">
                {user.name.charAt(0).toUpperCase()}
              </div>
              <h2 className="text-2xl font-black text-gray-900">{user.name}</h2>
              <p className="text-gray-400 text-sm font-bold uppercase tracking-wider mt-1">Cliente Premium</p>
            </div>

            <div className="space-y-4">
              <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-2xl">
                <Mail className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="text-[10px] font-black text-gray-400 uppercase">E-mail</p>
                  <p className="text-sm font-bold text-gray-800">{user.email}</p>
                </div>
              </div>
              <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-2xl">
                <Phone className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="text-[10px] font-black text-gray-400 uppercase">Telefone</p>
                  <p className="text-sm font-bold text-gray-800">{user.phone}</p>
                </div>
              </div>
              <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-2xl">
                <Calendar className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="text-[10px] font-black text-gray-400 uppercase">Membro desde</p>
                  <p className="text-sm font-bold text-gray-800">
                    {new Date(user.createdAt).toLocaleDateString('pt-BR')}
                  </p>
                </div>
              </div>
            </div>

            <button
              onClick={logout}
              className="w-full bg-red-50 text-red-600 font-black py-4 rounded-2xl mt-8 flex items-center justify-center gap-2 hover:bg-red-100 transition-colors"
            >
              <LogOut className="h-5 w-5" />
              SAIR DA CONTA
            </button>
          </motion.div>

          <div className="mt-8 bg-blue-50 border border-blue-100 rounded-2xl p-6 flex items-start gap-4">
            <ShieldCheck className="h-6 w-6 text-blue-600 mt-1" />
            <div>
              <h4 className="font-bold text-blue-900">Sua conta está segura</h4>
              <p className="text-xs text-blue-700 leading-relaxed mt-1">
                Seus dados estão protegidos e são usados apenas para melhorar sua experiência de economia no PreçoBaixo.
              </p>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="pb-24 bg-gray-50 min-h-screen max-w-7xl mx-auto">
      <header className="bg-white border-b sticky top-0 z-50 p-4 flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
          <ArrowLeft className="h-6 w-6" />
        </button>
        <h1 className="text-xl font-bold text-gray-800">Cadastrar Cliente</h1>
      </header>

      <main className="max-w-md mx-auto p-6 md:pt-12">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8"
        >
          <div className="flex justify-center mb-8">
            <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center">
              <UserPlus className="h-10 w-10 text-blue-600" />
            </div>
          </div>

          {isSubmitted ? (
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="text-center py-8"
            >
              <CheckCircle2 className="h-16 w-16 text-emerald-500 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-gray-800 mb-2">Sucesso!</h2>
              <p className="text-gray-500">O cliente foi cadastrado com sucesso no sistema.</p>
            </motion.div>
          ) : (
            <>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2 ml-1">
                    Nome Completo
                  </label>
                  <div className="relative">
                    <input
                      required
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Ex: João Silva"
                      className="w-full bg-gray-50 border-none rounded-2xl py-4 px-12 focus:ring-2 focus:ring-blue-500 transition-all outline-none"
                    />
                    <User className="absolute left-4 top-4 h-5 w-5 text-gray-400" />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2 ml-1">
                    E-mail
                  </label>
                  <div className="relative">
                    <input
                      required
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="joao@exemplo.com"
                      className="w-full bg-gray-50 border-none rounded-2xl py-4 px-12 focus:ring-2 focus:ring-blue-500 transition-all outline-none"
                    />
                    <Mail className="absolute left-4 top-4 h-5 w-5 text-gray-400" />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2 ml-1">
                    Telefone
                  </label>
                  <div className="relative">
                    <input
                      required
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="(11) 99999-9999"
                      className="w-full bg-gray-50 border-none rounded-2xl py-4 px-12 focus:ring-2 focus:ring-blue-500 transition-all outline-none"
                    />
                    <Phone className="absolute left-4 top-4 h-5 w-5 text-gray-400" />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2 ml-1">
                    Senha
                  </label>
                  <div className="relative">
                    <input
                      required
                      type="password"
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      placeholder="••••••••"
                      className="w-full bg-gray-50 border-none rounded-2xl py-4 px-12 focus:ring-2 focus:ring-blue-500 transition-all outline-none"
                    />
                    <Lock className="absolute left-4 top-4 h-5 w-5 text-gray-400" />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white font-black py-4 rounded-2xl shadow-xl shadow-blue-600/20 active:scale-95 transition-transform mt-4"
                >
                  CADASTRAR CLIENTE
                </button>
              </form>

              <div className="mt-8 text-center">
                <p className="text-sm text-gray-500 mb-4">Já possui cadastro?</p>
                <Link 
                  to="/login" 
                  className="inline-flex items-center gap-2 text-blue-600 font-bold hover:underline"
                >
                  <LogIn className="h-4 w-4" />
                  Entrar na minha conta
                </Link>
              </div>
            </>
          )}
        </motion.div>
      </main>
    </div>
  );
}
