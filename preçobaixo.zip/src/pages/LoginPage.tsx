import React, { useState } from "react";
import { motion } from "motion/react";
import { LogIn, ArrowLeft, Mail, AlertCircle, UserPlus, Lock } from "lucide-react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "@/src/contexts/AuthContext";

export default function LoginPage() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const success = login(email, password);
    if (success) {
      navigate("/");
    } else {
      setError("E-mail ou senha incorretos. Verifique os dados ou cadastre-se.");
    }
  };

  return (
    <div className="pb-24 bg-gray-50 min-h-screen max-w-7xl mx-auto">
      <header className="bg-white border-b sticky top-0 z-50 p-4 flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
          <ArrowLeft className="h-6 w-6" />
        </button>
        <h1 className="text-xl font-bold text-gray-800">Entrar</h1>
      </header>

      <main className="max-w-md mx-auto p-6 md:pt-12">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8"
        >
          <div className="flex justify-center mb-8">
            <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center">
              <LogIn className="h-10 w-10 text-blue-600" />
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <div className="bg-red-50 text-red-600 p-4 rounded-2xl text-sm flex items-center gap-2 border border-red-100">
                <AlertCircle className="h-5 w-5 flex-shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <div>
              <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2 ml-1">
                Seu E-mail de Cadastro
              </label>
              <div className="relative">
                <input
                  required
                  type="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    setError("");
                  }}
                  placeholder="exemplo@email.com"
                  className="w-full bg-gray-50 border-none rounded-2xl py-4 px-12 focus:ring-2 focus:ring-blue-500 transition-all outline-none"
                />
                <Mail className="absolute left-4 top-4 h-5 w-5 text-gray-400" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-2 ml-1">
                Sua Senha
              </label>
              <div className="relative">
                <input
                  required
                  type="password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setError("");
                  }}
                  placeholder="••••••••"
                  className="w-full bg-gray-50 border-none rounded-2xl py-4 px-12 focus:ring-2 focus:ring-blue-500 transition-all outline-none"
                />
                <Lock className="absolute left-4 top-4 h-5 w-5 text-gray-400" />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 text-white font-black py-4 rounded-2xl shadow-xl shadow-blue-600/20 active:scale-95 transition-transform mt-4"
            >
              ENTRAR NO PREÇOBAIXO
            </button>
          </form>

          <div className="mt-8 text-center">
            <p className="text-sm text-gray-500 mb-4">Ainda não tem cadastro?</p>
            <Link 
              to="/register" 
              className="inline-flex items-center gap-2 text-blue-600 font-bold hover:underline"
            >
              <UserPlus className="h-4 w-4" />
              Cadastrar novo cliente
            </Link>
          </div>
        </motion.div>
      </main>
    </div>
  );
}
