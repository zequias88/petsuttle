import { motion } from "motion/react";
import { CATEGORIES, PRODUCTS } from "@/src/constants";
import * as Icons from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import { formatCurrency } from "@/src/lib/utils";
import { useState, useMemo, useRef, useEffect } from "react";

export default function HomePage() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [showOnlyBestDeals, setShowOnlyBestDeals] = useState(false);
  const productsSectionRef = useRef<HTMLElement>(null);
  const location = useLocation();

  // Reset filters when navigating to home (e.g. clicking "Início" in nav)
  useEffect(() => {
    if (location.pathname === '/' && !location.search && !location.hash) {
      // If we are at root and no specific state was passed, we could reset
      // but we want to be careful not to reset if the user just clicked a category
      // which also keeps them on '/'.
      // Actually, clicking the Link in Layout.tsx will just set the path to '/'.
      // A better way is to check if the user explicitly clicked the "Início" button.
      // But since we don't have a global state for this, we can just reset if 
      // the user navigates to '/' from another page, or if they click the link.
    }
  }, [location]);

  const filteredProducts = useMemo(() => {
    let result = PRODUCTS;
    
    if (selectedCategory) {
      result = result.filter(p => p.category.toLowerCase() === selectedCategory.toLowerCase());
    }
    
    if (showOnlyBestDeals) {
      result = result.filter(p => p.discount >= 20);
    }
    
    return result;
  }, [selectedCategory, showOnlyBestDeals]);

  const scrollToProducts = () => {
    productsSectionRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleBestDealsClick = () => {
    setShowOnlyBestDeals(true);
    setSelectedCategory(null);
    scrollToProducts();
  };

  const handleCategoryClick = (catId: string) => {
    if (selectedCategory === catId) {
      setSelectedCategory(null);
    } else {
      setSelectedCategory(catId);
      setShowOnlyBestDeals(false);
    }
    scrollToProducts();
  };

  return (
    <div className="pb-24 max-w-7xl mx-auto">
      {/* Hero Banner */}
      <section className="p-4 md:py-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-blue-700 to-blue-900 rounded-3xl p-8 md:p-12 text-white shadow-xl relative overflow-hidden"
        >
          <div className="relative z-10 md:max-w-xl">
            <h2 className="text-3xl md:text-5xl font-black mb-4 leading-tight">Economize até 40% em suas compras</h2>
            <p className="text-sm md:text-lg opacity-90 mb-8 max-w-[400px]">
              Encontramos os melhores preços nas maiores lojas do Brasil em tempo real. Compare e economize agora.
            </p>
            <button 
              onClick={handleBestDealsClick}
              className="bg-emerald-500 hover:bg-emerald-600 text-white font-black py-4 px-10 rounded-2xl transition-all shadow-xl shadow-emerald-900/40 active:scale-95"
            >
              Ver Ofertas Imperdíveis
            </button>
          </div>
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-32 -mt-32 blur-3xl" />
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full -mr-48 -mb-48 blur-3xl" />
        </motion.div>
      </section>

      {/* Categories */}
      <section className="p-4 md:py-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl md:text-2xl font-black text-gray-800">Categorias</h2>
          <button 
            onClick={() => { setSelectedCategory(null); setShowOnlyBestDeals(false); }}
            className="text-blue-600 text-sm font-bold hover:underline"
          >
            Ver todas
          </button>
        </div>
        <div className="grid grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-4 md:gap-6">
          {CATEGORIES.map((cat) => {
            // @ts-ignore
            const Icon = Icons[cat.icon];
            const isActive = selectedCategory === cat.id;
            return (
              <motion.button 
                key={cat.id}
                onClick={() => handleCategoryClick(cat.id)}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="flex flex-col items-center gap-2 group"
              >
                <div className={`w-14 h-14 ${cat.color} ${isActive ? 'ring-4 ring-blue-600 ring-offset-2' : ''} rounded-2xl flex items-center justify-center shadow-sm transition-all`}>
                  <Icon className="h-7 w-7" />
                </div>
                <span className={`text-[11px] font-semibold text-center ${isActive ? 'text-blue-600 font-black' : 'text-gray-600'}`}>{cat.name}</span>
              </motion.button>
            );
          })}
        </div>
      </section>

      {/* Deals of the Day */}
      <section ref={productsSectionRef} className="py-4 md:py-8">
        <div className="px-4 flex justify-between items-center mb-6">
          <h2 className="text-xl md:text-2xl font-black text-gray-800">
            {showOnlyBestDeals ? "Ofertas Imperdíveis" : selectedCategory ? `Ofertas em ${CATEGORIES.find(c => c.id === selectedCategory)?.name}` : "Ofertas do Dia"}
          </h2>
          <div className="flex items-center text-emerald-500 gap-2 text-sm font-black uppercase tracking-widest">
            <span className="flex h-3 w-3 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>Ao Vivo</span>
          </div>
        </div>
        
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6 px-4">
            {filteredProducts.map((product) => (
              <Link 
                key={product.id}
                to={`/product/${product.id}`}
                className="bg-white rounded-3xl shadow-sm border border-gray-100 p-4 flex flex-col group hover:shadow-xl hover:border-blue-100 transition-all duration-300"
              >
                <div className="relative mb-4 aspect-square flex items-center justify-center bg-gray-50 rounded-2xl overflow-hidden">
                  <img 
                    src={product.image} 
                    alt={product.name}
                    className="w-full h-full object-contain p-4 group-hover:scale-110 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-2 right-2 bg-red-500 text-white text-[10px] font-black px-3 py-1.5 rounded-full shadow-lg">
                    -{product.discount}%
                  </div>
                </div>
                <h3 className="text-sm font-bold line-clamp-2 mb-3 text-gray-800 h-10 leading-tight">
                  {product.name}
                </h3>
                <div className="mt-auto">
                  <span className="text-xs text-gray-400 line-through block font-medium">
                    {formatCurrency(product.originalPrice)}
                  </span>
                  <div className="flex items-baseline gap-1">
                    <span className="text-lg font-black text-emerald-600">
                      {formatCurrency(product.currentPrice)}
                    </span>
                  </div>
                </div>
                <div className="flex gap-2 mt-4">
                  <button className="flex-1 py-3 text-xs font-black text-blue-700 bg-blue-50 rounded-2xl group-hover:bg-blue-600 group-hover:text-white transition-all">
                    COMPARAR
                  </button>
                  <button 
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      const bestStore = product.stores.find(s => s.isBestPrice) || product.stores[0];
                      if (bestStore?.url) window.open(bestStore.url, '_blank');
                    }}
                    className="p-3 text-white bg-emerald-500 rounded-2xl hover:bg-emerald-600 transition-all shadow-lg shadow-emerald-500/20"
                    title="Ir para a loja"
                  >
                    <Icons.ExternalLink className="h-4 w-4" />
                  </button>
                </div>
              </Link>
            ))}
          </div>
        ) : (
          <div className="px-4 py-20 text-center">
            <Icons.SearchX className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-gray-800">Nenhum produto encontrado</h3>
            <p className="text-gray-500">Tente selecionar outra categoria ou limpar os filtros.</p>
            <button 
              onClick={() => { setSelectedCategory(null); setShowOnlyBestDeals(false); }}
              className="mt-6 text-blue-600 font-black uppercase tracking-widest text-sm"
            >
              Ver todos os produtos
            </button>
          </div>
        )}
      </section>

      {/* Trust Section */}
      <section className="p-4 bg-white mt-4 border-y border-gray-100">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-emerald-50 rounded-2xl">
            <Icons.ShieldCheck className="h-6 w-6 text-emerald-500" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-gray-800">Compra 100% Segura</h4>
            <p className="text-xs text-gray-500">Monitoramos apenas lojas confiáveis e certificadas.</p>
          </div>
        </div>
      </section>
    </div>
  );
}
