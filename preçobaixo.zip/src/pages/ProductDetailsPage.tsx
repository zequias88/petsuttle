import { useParams, useNavigate } from "react-router-dom";
import { PRODUCTS } from "@/src/constants";
import { ChevronLeft, Share2, TrendingDown, Star, ExternalLink } from "lucide-react";
import { formatCurrency, cn } from "@/src/lib/utils";
import { motion } from "motion/react";

export default function ProductDetailsPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const product = PRODUCTS.find((p) => p.id === id);

  if (!product) {
    return (
      <div className="p-8 text-center">
        <p>Produto não encontrado.</p>
        <button onClick={() => navigate("/")} className="text-blue-600 font-bold mt-4">
          Voltar para o início
        </button>
      </div>
    );
  }

  return (
    <div className="pb-24 bg-gray-50 min-h-screen max-w-7xl mx-auto">
      <header className="bg-white border-b sticky top-0 z-50 p-4 flex items-center justify-between">
        <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
          <ChevronLeft className="h-6 w-6" />
        </button>
        <h1 className="text-lg font-bold truncate max-w-[200px]">{product.name}</h1>
        <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
          <Share2 className="h-6 w-6" />
        </button>
      </header>

      <main className="max-w-7xl mx-auto md:p-8">
        <div className="md:grid md:grid-cols-2 md:gap-12 md:items-start">
          {/* Left Column: Image and Basic Info */}
          <div className="space-y-6">
            <section className="bg-white p-6 md:p-12 flex flex-col items-center border-b md:border md:rounded-3xl md:shadow-sm">
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="relative w-full aspect-square max-w-[400px]"
              >
                <img 
                  src={product.image} 
                  alt={product.name}
                  className="w-full h-full object-contain"
                  referrerPolicy="no-referrer"
                />
              </motion.div>
              <div className="mt-8 text-center">
                <span className="bg-blue-100 text-blue-800 text-xs font-black px-4 py-1.5 rounded-full uppercase tracking-widest">
                  Lançamento
                </span>
                <h2 className="mt-4 text-2xl md:text-3xl font-black px-4 text-gray-900 leading-tight">
                  {product.name}
                </h2>
              </div>
            </section>

            {/* Price History (Desktop) */}
            <section className="hidden md:block bg-white p-8 border rounded-3xl shadow-sm">
              <h3 className="font-black text-gray-800 mb-8 uppercase tracking-widest text-sm">Histórico de Preços (6 meses)</h3>
              <div className="h-48 flex items-end justify-between gap-3 px-2">
                {product.history.map((h, i) => {
                  const maxHeight = 100;
                  const minPrice = Math.min(...product.history.map(x => x.price));
                  const maxPrice = Math.max(...product.history.map(x => x.price));
                  const height = ((h.price - minPrice * 0.9) / (maxPrice - minPrice * 0.9)) * maxHeight;
                  
                  return (
                    <div key={h.month} className="flex flex-col items-center flex-1">
                      <motion.div 
                        initial={{ height: 0 }}
                        animate={{ height: `${height}%` }}
                        className={cn(
                          "w-full rounded-t-lg transition-all duration-500",
                          i === product.history.length - 1 ? "bg-blue-600 shadow-lg shadow-blue-200" : "bg-gray-100"
                        )}
                      />
                      <span className={cn(
                        "text-[10px] mt-3 font-black uppercase tracking-tighter",
                        i === product.history.length - 1 ? "text-blue-600" : "text-gray-400"
                      )}>
                        {h.month}
                      </span>
                    </div>
                  );
                })}
              </div>
            </section>
          </div>

          {/* Right Column: Pricing and Stores */}
          <div className="space-y-6 mt-2 md:mt-0">
            {/* Price Highlight */}
            <section className="bg-white p-8 border-y md:border md:rounded-3xl md:shadow-sm text-center md:text-left">
              <p className="text-xs text-gray-400 font-black uppercase tracking-widest mb-2">Melhor preço hoje</p>
              <div className="flex items-baseline justify-center md:justify-start gap-2 text-emerald-600">
                <span className="text-2xl font-black">R$</span>
                <span className="text-5xl font-black tracking-tighter">{product.currentPrice.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
              </div>
              <p className="text-sm text-gray-500 mt-2 font-medium">
                à vista no PIX na <span className="font-black text-gray-800">{product.stores[0].name}</span>
              </p>
              <div className="mt-6 bg-emerald-50 text-emerald-700 px-6 py-3 rounded-2xl inline-flex items-center gap-3 border border-emerald-100">
                <TrendingDown className="h-5 w-5" />
                <span className="text-sm font-black uppercase tracking-wide">Menor preço dos últimos 30 dias</span>
              </div>
              
              <div className="hidden md:block mt-8">
                <button 
                  onClick={() => product.stores[0].url && window.open(product.stores[0].url, '_blank')}
                  className="w-full bg-orange-500 hover:bg-orange-600 text-white font-black py-5 rounded-2xl shadow-xl shadow-orange-500/30 active:scale-95 transition-all text-lg uppercase tracking-widest"
                >
                  IR PARA A LOJA AGORA
                </button>
              </div>
            </section>

            {/* Stores List */}
            <section className="bg-white p-8 border-y md:border md:rounded-3xl md:shadow-sm">
              <h3 className="font-black text-gray-800 mb-6 uppercase tracking-widest text-sm">Onde Comprar</h3>
              <div className="space-y-4">
                {product.stores.map((store) => (
                  <div 
                    key={store.name}
                    className="flex items-center justify-between p-5 border border-gray-100 rounded-2xl hover:border-blue-600 hover:shadow-lg transition-all group cursor-pointer"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-14 h-14 bg-gray-50 rounded-2xl flex items-center justify-center font-black text-blue-900 text-xl shadow-inner">
                        {store.name.substring(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <p className="text-sm font-black text-gray-900">{store.name}</p>
                        <p className="text-lg text-emerald-600 font-black tracking-tight">{formatCurrency(store.price)}</p>
                        {store.condition && <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">{store.condition}</p>}
                      </div>
                    </div>
                    <button 
                      onClick={() => store.url && window.open(store.url, '_blank')}
                      className="bg-blue-600 text-white text-xs font-black px-6 py-3 rounded-xl shadow-lg shadow-blue-900/10 active:scale-95 transition-transform uppercase tracking-widest"
                    >
                      Ir à loja
                    </button>
                  </div>
                ))}
              </div>
            </section>

            {/* Reviews */}
            <section className="bg-white p-8 border-y md:border md:rounded-3xl md:shadow-sm">
              <div className="flex items-center justify-between mb-8">
                <h3 className="font-black text-gray-800 uppercase tracking-widest text-sm">Avaliações</h3>
                <div className="flex items-center gap-2 bg-yellow-50 px-4 py-2 rounded-full border border-yellow-100">
                  <span className="text-sm font-black text-yellow-700">{product.rating}</span>
                  <Star className="w-4 h-4 text-yellow-500 fill-current" />
                  <span className="text-xs text-yellow-600 font-bold">({product.reviewsCount})</span>
                </div>
              </div>
              <div className="space-y-8">
                <div className="border-b border-gray-100 pb-6">
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-sm font-black italic text-gray-800">João Silva</span>
                    <span className="text-[10px] text-gray-400 font-black uppercase tracking-widest">HÁ 2 DIAS</span>
                  </div>
                  <div className="flex gap-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-sm text-gray-600 leading-relaxed font-medium">
                    Smartphone incrível! A tela é espetacular e a bateria dura o dia todo com facilidade. Recomendo muito.
                  </p>
                </div>
              </div>
              <button className="w-full mt-8 text-blue-600 text-xs font-black py-4 border-2 border-blue-100 rounded-2xl hover:bg-blue-50 hover:border-blue-200 transition-all uppercase tracking-widest">
                Ver todas as avaliações
              </button>
            </section>
          </div>
        </div>
      </main>

      {/* Sticky CTA (Mobile Only) */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t p-4 flex items-center justify-between gap-4 z-50 shadow-[0_-8px_30px_rgba(0,0,0,0.1)]">
        <div>
          <p className="text-[10px] text-gray-400 uppercase font-black tracking-widest">A partir de</p>
          <p className="text-2xl font-black text-emerald-600 leading-none tracking-tighter">
            {formatCurrency(product.currentPrice)}
          </p>
        </div>
        <button 
          onClick={() => product.stores[0].url && window.open(product.stores[0].url, '_blank')}
          className="flex-1 bg-orange-500 text-white font-black py-4 rounded-2xl shadow-xl shadow-orange-500/30 active:scale-95 transition-transform uppercase tracking-widest"
        >
          VER OFERTAS
        </button>
      </div>
    </div>
  );
}
