import { motion } from "motion/react";
import { PRODUCTS } from "@/src/constants";
import { Trash2, Plus, Settings2, Search, ArrowLeft } from "lucide-react";
import { formatCurrency } from "@/src/lib/utils";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function WishlistPage() {
  const navigate = useNavigate();
  const [alertsEnabled, setAlertsEnabled] = useState(true);
  
  const wishlistItems = [
    { ...PRODUCTS[0], meta: 3600, status: "Preço atingido!" },
    { ...PRODUCTS[1], meta: 4800, status: "Faltam R$ 399" },
    { ...PRODUCTS[2], meta: 1100, status: "Faltam R$ 150" },
  ];

  return (
    <div className="pb-24 bg-gray-50 min-h-screen max-w-7xl mx-auto">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="px-4 py-4 flex items-center gap-4 max-w-md mx-auto md:max-w-none">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
            <ArrowLeft className="h-6 w-6" />
          </button>
          <h1 className="text-xl font-bold text-gray-800 flex-1">Meus Desejos</h1>
          <button className="p-2 text-gray-500 hover:text-blue-600 transition-colors">
            <Search className="h-6 w-6" />
          </button>
        </div>
      </header>

      <main className="max-w-md mx-auto">
        {/* Quick Settings */}
        <section className="p-4 bg-white mb-2 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-bold text-gray-800">Alertas por E-mail</h2>
              <p className="text-sm text-gray-500">Receba notificações de queda de preço</p>
            </div>
            <button 
              onClick={() => setAlertsEnabled(!alertsEnabled)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${
                alertsEnabled ? 'bg-blue-600' : 'bg-gray-300'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  alertsEnabled ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
        </section>

        {/* Wishlist Items */}
        <section className="px-4 py-4">
          <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-4">
            Produtos Salvos ({wishlistItems.length})
          </h3>
          <div className="space-y-4">
            {wishlistItems.map((item) => (
              <motion.div 
                key={item.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-white rounded-2xl shadow-sm overflow-hidden border border-gray-100 flex p-4 gap-4"
              >
                <div className="w-24 h-24 bg-gray-50 rounded-xl flex-shrink-0 overflow-hidden">
                  <img 
                    src={item.image} 
                    alt={item.name}
                    className="w-full h-full object-contain"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="flex-grow flex flex-col justify-between">
                  <div>
                    <h4 className="font-bold text-gray-900 line-clamp-1 text-sm">{item.name}</h4>
                    <div className="mt-1 flex items-baseline gap-2">
                      <span className="text-lg font-black text-blue-600">{formatCurrency(item.currentPrice)}</span>
                      <span className="text-[10px] text-gray-400 line-through">{formatCurrency(item.originalPrice)}</span>
                    </div>
                    <div className={`mt-1 inline-flex items-center text-[10px] font-black px-2 py-1 rounded-lg ${
                      item.status.includes("atingido") ? "bg-emerald-50 text-emerald-600" : "bg-gray-100 text-gray-600"
                    }`}>
                      Meta: {formatCurrency(item.meta)}
                    </div>
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <span className={`text-[10px] font-bold italic ${
                      item.status.includes("atingido") ? "text-emerald-500" : "text-gray-400"
                    }`}>
                      {item.status}
                    </span>
                    <button className="text-[10px] font-black text-red-500 uppercase flex items-center gap-1">
                      <Trash2 className="h-3 w-3" />
                      Remover
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Management Actions */}
        <section className="p-4 mt-2">
          <div className="bg-blue-50 border border-blue-100 rounded-2xl p-6">
            <h3 className="font-bold text-blue-900 mb-1">Gerenciar Alertas</h3>
            <p className="text-sm text-blue-700/70 mb-6">
              Você está monitorando {wishlistItems.length} produtos em 5 lojas diferentes.
            </p>
            <div className="grid grid-cols-2 gap-4">
              <button className="bg-white text-blue-600 border border-blue-200 py-3.5 px-4 rounded-2xl text-sm font-bold shadow-sm active:scale-95 transition-transform flex items-center justify-center gap-2">
                <Settings2 className="h-4 w-4" />
                Editar Metas
              </button>
              <button className="bg-blue-600 text-white py-3.5 px-4 rounded-2xl text-sm font-bold shadow-sm active:scale-95 transition-transform flex items-center justify-center gap-2">
                <Plus className="h-4 w-4" />
                Novo Alerta
              </button>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
