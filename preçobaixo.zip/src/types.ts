export interface StorePrice {
  name: string;
  price: number;
  url?: string;
  condition?: string;
  isBestPrice?: boolean;
  logo?: string;
}

export interface Product {
  id: string;
  name: string;
  brand: string;
  category: string;
  image: string;
  originalPrice: number;
  currentPrice: number;
  discount: number;
  rating: number;
  reviewsCount: number;
  stores: StorePrice[];
  history: { month: string; price: number }[];
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  password?: string;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  color: string;
}
