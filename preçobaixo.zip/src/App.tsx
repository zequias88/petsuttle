import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Header, BottomNav, Footer } from "./components/Layout";
import HomePage from "./pages/HomePage";
import ProductDetailsPage from "./pages/ProductDetailsPage";
import WishlistPage from "./pages/WishlistPage";
import CustomerRegistrationPage from "./pages/CustomerRegistrationPage";
import LoginPage from "./pages/LoginPage";
import { AuthProvider } from "./contexts/AuthContext";
import { SearchProvider } from "./contexts/SearchContext";

export default function App() {
  return (
    <AuthProvider>
      <SearchProvider>
        <Router>
          <div className="min-h-screen bg-gray-50 flex flex-col">
            <Routes>
            <Route 
              path="/" 
              element={
                <>
                  <Header />
                  <HomePage />
                  <Footer />
                  <BottomNav />
                </>
              } 
            />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<CustomerRegistrationPage />} />
            <Route 
              path="/wishlist" 
              element={
                <>
                  <Header />
                  <WishlistPage />
                  <Footer />
                  <BottomNav />
                </>
              } 
            />
            <Route 
              path="/alerts" 
              element={
                <>
                  <Header />
                  <WishlistPage />
                  <Footer />
                  <BottomNav />
                </>
              } 
            />
            <Route 
              path="/profile" 
              element={
                <>
                  <Header />
                  <CustomerRegistrationPage />
                  <Footer />
                  <BottomNav />
                </>
              } 
            />
            <Route 
              path="/product/:id" 
              element={
                <>
                  <ProductDetailsPage />
                  <Footer />
                </>
              } 
            />
          </Routes>
        </div>
      </Router>
      </SearchProvider>
    </AuthProvider>
  );
}
